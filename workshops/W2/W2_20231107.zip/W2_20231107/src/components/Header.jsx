import { Component  } from "react";

class Header extends Component {

  render() {

    return (<header>
        <h1>Pokemon API</h1>
        <p>Pokemon API with React</p>
    </header>);
  }
}

export default Header;
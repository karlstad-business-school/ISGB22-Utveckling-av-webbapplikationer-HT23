import { Component  } from "react";
import UIRoot from "./components/UIRoot";
import "./App.css";

class App extends Component {

  render() {

    return ( <UIRoot /> );
  }
}

export default App;

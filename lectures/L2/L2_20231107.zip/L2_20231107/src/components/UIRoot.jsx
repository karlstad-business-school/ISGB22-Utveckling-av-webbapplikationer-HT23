import { Component } from "react";

class UIRoot extends Component {

    dettaarminmetod() {
        //Ren js
    }

  render() {

    let kursnamn = "Utveckling av webbapplikationer";
    let a = this.props.a;
    let b = this.props.b;

    return( 
        <>

            <header>{a + b}</header>
            <main>Main</main>
            <footer>Footer</footer>
        </>
    );

  }
}

export default UIRoot;
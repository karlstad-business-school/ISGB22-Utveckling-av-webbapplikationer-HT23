import { Component } from "react";
import UIRoot from "./components/UIRoot";

class App extends Component {

  render() {

    return( <UIRoot a="a" b="b" /> );

  }
}

export default App ;
